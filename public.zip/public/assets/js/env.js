/**
 * Created by Ashhal on 10/8/2016.
 */
var domain = "http://"+window.location.hostname+"/nugree/public/";
var api = "api/v1/";
var apiPath = domain+api;

/**  Algolia keys **/
var ALGOLIA_APPLICATION_ID = "870383THWM";
var ALGOLIA_API_KEY = "943370cc01a7f371bcdd2f3beab23ccc";
var ALGOLIA_INDEX = "pro_nugree_locations";