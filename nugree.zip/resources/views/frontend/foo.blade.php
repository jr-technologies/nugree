<h1> This URL will be refresh in 10 Second</h1>

<script>
    var intervalID = window.setInterval(myCallback, 10000);
    function myCallback() {
        location.reload();
    }
</script>