@extends('frontend.v1.frontend')
@section('content')
    <div class="page-holder">
     <h1>Property #{{$response['data']['propertyId']}} Not Found </h1>
    </div>
@endsection