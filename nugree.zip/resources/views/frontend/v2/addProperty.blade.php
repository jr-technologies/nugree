@extends('frontend.v2.frontend')
@section('content')
    <div id="content">
        <div class="container">
            <div class="page-holder">
                <div class="addPropertyForm-page">

                </div>
            </div>
        </div>
    </div>
@endsection