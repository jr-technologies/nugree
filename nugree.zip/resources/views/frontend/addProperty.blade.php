@extends('frontend.frontend_old')
@section('content')
    <div id="content">
        <div class="container">
            <div class="page-holder">
                <div class="addPropertyForm-page">

                </div>
            </div>
        </div>
    </div>
@endsection