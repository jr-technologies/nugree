@extends('admin.admin2')
@section('content')
   <input type="text" name="society" placeholder="Please Enter A society" >
    <input type="button" value="submit">
@endsection