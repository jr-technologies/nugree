<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 3/31/2016
 * Time: 11:02 PM
 */

namespace App\Collections\Interfaces;


interface CollectionInterface {

} 