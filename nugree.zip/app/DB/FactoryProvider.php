<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 4/1/2016
 * Time: 9:39 PM
 */

namespace App\DB;


abstract class FactoryProvider {

}