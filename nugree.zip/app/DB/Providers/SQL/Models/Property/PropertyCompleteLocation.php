<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 4/26/2016
 * Time: 9:18 PM
 */
namespace App\DB\Providers\SQL\Models\Property;

class PropertyCompleteLocation {
    public $country = null;
    public $city = null;
    //public $society = null;
    public $location = null;
} 