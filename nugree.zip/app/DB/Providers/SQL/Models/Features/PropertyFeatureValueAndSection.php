<?php
/**
 * Created by PhpStorm.
 * User: waqas
 * Date: 4/6/2016
 * Time: 10:17 AM
 **/

namespace App\DB\Providers\SQL\Models\Features;

class PropertyFeatureValueAndSection {
    public $propertyId = 0;
    public $featureId =0;
    public $featureName ="";
    public $featureInputName="";
    public $possibleValues="";
    public $section=null;
    public $value="";
    public $priority=0;
    public $htmlStructure="";
} 

