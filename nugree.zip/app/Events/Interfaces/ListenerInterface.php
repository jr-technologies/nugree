<?php
/**
 * Created by PhpStorm.
 * User: waqas
 * Date: 3/25/2016
 * Time: 10:43 AM
 */

namespace App\Events\Interfaces;


interface ListenerInterface
{

}